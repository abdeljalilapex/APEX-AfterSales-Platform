"""
main.py — API FastAPI, Étape 3 du pivot backend.

Expose le moteur KPI déjà porté (kpi_engine_py, Étape 2) sans aucune
réécriture de sa logique : cette couche ne fait que router des requêtes
HTTP vers les fonctions déjà testées (calculate, resoudre_sources) et
sérialiser leurs résultats.

Gestion de connexion (décision d'architecture, cf. ADR-032) : l'engine
SQLAlchemy et les métadonnées réfléchies sont créés UNE SEULE FOIS au
démarrage de l'application (lifespan), pas à chaque requête — coûteux
sinon (la réflexion du schéma fait une requête réseau à chaque appel).
Une connexion est ouverte par requête via une dépendance FastAPI
(Depends), fermée automatiquement en fin de requête.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException

from kpi_engine_py import get_engine, reflect_metadata
from kpi_engine_py.engine import calculate as engine_calculate
from kpi_engine_py.provenance import resoudre_sources
from sqlalchemy import select

from .schemas import KPIDefinitionOut, CalculerRequest, KPIValueOut, SourceRecordOut

_state = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    engine = get_engine()
    metadata = reflect_metadata(engine)
    _state["engine"] = engine
    _state["metadata"] = metadata
    yield
    _state.clear()


app = FastAPI(title="APEX KPI Engine API", version="0.1.0", lifespan=lifespan)


def get_conn():
    conn = _state["engine"].connect()
    try:
        yield conn
    finally:
        conn.close()


def get_metadata():
    return _state["metadata"]


@app.get("/health")
def health():
    return {"statut": "ok"}


@app.get("/kpi-definitions", response_model=list[KPIDefinitionOut])
def lister_definitions(conn=Depends(get_conn), metadata=Depends(get_metadata)):
    table = metadata.tables["kpi_definitions"]
    rows = conn.execute(select(table)).mappings().all()
    return [dict(r) for r in rows]


@app.post("/kpi/{kpi_id}/calculer", response_model=KPIValueOut)
def calculer(kpi_id: str, requete: CalculerRequest, conn=Depends(get_conn), metadata=Depends(get_metadata)):
    try:
        resultat = engine_calculate(
            conn, metadata, kpi_id,
            requete.periode_debut, requete.periode_fin, requete.concession_id,
            version=requete.version, auteur=requete.auteur,
        )
    except ValueError as e:
        # KPIDefinition introuvable, opérateur non supporté, etc. — erreur
        # explicite du moteur, traduite en 404/400 plutôt qu'un 500 opaque.
        raise HTTPException(status_code=404, detail=str(e))
    return resultat


@app.get("/kpi/{kpi_id}/valeurs", response_model=list[KPIValueOut])
def lister_valeurs(kpi_id: str, concession_id: str | None = None,
                    conn=Depends(get_conn), metadata=Depends(get_metadata)):
    table = metadata.tables["kpi_values"]
    stmt = select(table).where(table.c.kpi_id == kpi_id)
    if concession_id:
        stmt = stmt.where(table.c.concession_id == concession_id)
    stmt = stmt.order_by(table.c.periode_debut)
    rows = conn.execute(stmt).mappings().all()
    return [dict(r) for r in rows]


@app.get("/kpi-values/{value_id}/sources", response_model=list[SourceRecordOut])
def sources_kpi_value(value_id: str, conn=Depends(get_conn), metadata=Depends(get_metadata)):
    table = metadata.tables["kpi_values"]
    kv = conn.execute(select(table).where(table.c.id == value_id)).mappings().first()
    if kv is None:
        raise HTTPException(status_code=404, detail=f"KPIValue introuvable : {value_id}")
    enregistrements = resoudre_sources(conn, metadata, dict(kv))
    return [{"id": str(r["id"]), "donnees": {k: str(v) for k, v in r.items()}} for r in enregistrements]
