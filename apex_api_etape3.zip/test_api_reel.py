"""
test_api_reel.py — Exécution réelle de l'API FastAPI (TestClient) contre
PostgreSQL local. Pas de mock : les mêmes requêtes SQL réelles que
test_engine_reel.py, mais désormais via HTTP.
"""
import sys
sys.path.insert(0, "/home/claude/apex_backend")

from fastapi.testclient import TestClient
from api.main import app

CONCESSION_ID = "11111111-1111-1111-1111-111111111111"

with TestClient(app) as client:
    # ---- Healthcheck ----
    r = client.get("/health")
    print("GET /health ->", r.status_code, r.json())
    assert r.status_code == 200

    # ---- Liste des définitions ----
    r = client.get("/kpi-definitions")
    print("\nGET /kpi-definitions ->", r.status_code, "-", len(r.json()), "définitions")
    for d in r.json():
        print("   -", d["id"], "v" + str(d["version"]), "| date_champ_periode =", d["date_champ_periode"])
    assert r.status_code == 200
    assert len(r.json()) == 2

    # ---- Calcul réel : kpi-delai-rdv ----
    r = client.post("/kpi/kpi-delai-rdv/calculer", json={
        "periode_debut": "2026-07-20", "periode_fin": "2026-07-26",
        "concession_id": CONCESSION_ID, "auteur": "test-api-etape3",
    })
    print("\nPOST /kpi/kpi-delai-rdv/calculer ->", r.status_code)
    v1 = r.json()
    print("  ", {k: v for k, v in v1.items() if k != "id"})
    assert r.status_code == 200
    assert abs(v1["valeur"] - 3.5) < 0.001, "Valeur inattendue !"

    # ---- Calcul réel : kpi-nombre-or ----
    r = client.post("/kpi/kpi-nombre-or/calculer", json={
        "periode_debut": "2026-07-20", "periode_fin": "2026-07-26",
        "concession_id": CONCESSION_ID,
    })
    print("\nPOST /kpi/kpi-nombre-or/calculer ->", r.status_code)
    v2 = r.json()
    print("  ", {k: v for k, v in v2.items() if k != "id"})
    assert r.status_code == 200
    assert v2["valeur"] == 3

    # ---- Historique ----
    r = client.get(f"/kpi/kpi-nombre-or/valeurs?concession_id={CONCESSION_ID}")
    print("\nGET /kpi/kpi-nombre-or/valeurs ->", r.status_code, "-", len(r.json()), "valeur(s)")
    assert r.status_code == 200
    assert len(r.json()) == 1  # dédoublonnage : un seul enregistrement malgré 2 calculs (celui-ci + celui d'Étape 2)

    # ---- Provenance (drill-down, ADR-010) ----
    value_id = v2["id"]
    r = client.get(f"/kpi-values/{value_id}/sources")
    print("\nGET /kpi-values/{id}/sources ->", r.status_code, "-", len(r.json()), "enregistrement(s) source")
    assert r.status_code == 200
    assert len(r.json()) == v2["nb_enregistrements_sources"]
    print("  Premier enregistrement source (extrait) :", list(r.json()[0]["donnees"].items())[:3])

    # ---- KPI inconnu -> 404 explicite, pas un 500 opaque ----
    r = client.post("/kpi/kpi-inexistant/calculer", json={
        "periode_debut": "2026-07-20", "periode_fin": "2026-07-26", "concession_id": CONCESSION_ID,
    })
    print("\nPOST /kpi/kpi-inexistant/calculer ->", r.status_code, "-", r.json())
    assert r.status_code == 404

    # ---- KPIValue inexistante -> 404 ----
    r = client.get("/kpi-values/00000000-0000-0000-0000-000000000000/sources")
    print("GET /kpi-values/{id-inexistant}/sources ->", r.status_code, "-", r.json())
    assert r.status_code == 404

print("\n=== TOUS LES TESTS API SONT PASSÉS ===")
